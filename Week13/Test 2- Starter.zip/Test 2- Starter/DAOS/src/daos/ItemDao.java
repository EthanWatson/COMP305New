package daos;

public class ItemDao {
    
}
